Sys.time()
rm(list=ls())
dev.off()
library(openxlsx)
library(plyr)
library(here)
# Declare directory
setwd(here())

###################################################################################################
# Set parameter for choice of country and ICS
###################################################################################################

ICS <- c(33,35)
country <- c("US")

###################################################################################################
# Load data compiled in Standards_database.R and costum-made functions
###################################################################################################

load("Backup_data/Standards_database.RData")
source("R_files/Aggregation_time_series.R")

###################################################################################################
# Aggregation and time series
###################################################################################################

# Balanced time series
all_ts <- expand.grid(c(1960:2014),c(1:4))
names(all_ts) <- c("year","quarter")
all_ts$time_q <- paste(all_ts$year,all_ts$quarter,sep="-") 

# Get counts
ts_count <- all_ts
ts_count <- merge(ts_count,agg_ts(all_ts,data_scdb, country, ICS, NA, "count_basic"),by="time_q", all.x = T)
ts_count <- merge(ts_count,agg_ts(all_ts,data_scdb[which(data_scdb$first == 1),], country, ICS, NA, "count_first"),by="time_q", all.x = T)
ts_count <- merge(ts_count,agg_ts(all_ts,data_scdb, country, ICS, "count_ref", "count_refweight"),by="time_q", all.x = T)
ts_count <- merge(ts_count,agg_ts(all_ts,data_scdb, country, ICS, "pagecount", "count_pagweight"),by="time_q", all.x = T)
ts_count <- ts_count[order(ts_count$time_q),]

# Save output
ctry <- NULL
for (i in seq(1,length(country))) ctry <- paste(ctry,country[i],sep='_')
ics <- NULL
for (i in seq(1,length(ICS))) ics <- paste(ics,ICS[i],sep='_')
write.xlsx(ts_count,paste0("Output_data/Standard_series",ics,ctry,".xlsx"))

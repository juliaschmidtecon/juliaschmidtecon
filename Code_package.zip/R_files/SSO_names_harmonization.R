sso_harm <- function(input_data) {
  sso_table <- input_data
  pattern <- "[A-Z]{3,10}"
  for (i in c(1:length(sso_table))) {
    string <- sso_table[i]
    if (length(regmatches(string, regexpr(pattern, string)))>0) {
      sso_table[i] <- paste(unique(unlist(regmatches(string, gregexpr(pattern, string)))),collapse = "/")
    }
  }
  for (i in c(1:length(sso_table))) {
    sso_table[i] <- gsub("W3C - World Wide Web Consortium","W3C",sso_table[i])
    sso_table[i] <- gsub("World Wide Web Consortium \\(W3C\\)","W3C",sso_table[i])
    sso_table[i] <- gsub("IEC\\/CEI)","IEC",sso_table[i])
    sso_table[i] <- gsub(paste0("IEC","/","CEI"),"IEC",sso_table[i])
  }
  sso_table
}

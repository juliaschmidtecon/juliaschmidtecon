agg_ts <- function(all_ts,input_data, country, ICS, weight, name_series) {
  # Select appropriate id depending on whether US/IX or US and IX combined
  if (length(country) == 1) {
    id <- "base_id_ind"
  } else {
    id <- "base_id_com"
  }
  ### Weights
  if (is.na(weight) == F) {
    input_data$weight_eval <- input_data[,weight]
    # Quarterly: quarters 1-4
    tscount_q_w <- ddply(input_data[which(input_data$ics2 %in% ICS & input_data$origincode %in% country & input_data[,id] == 1 &  input_data$quarter %in% c(1:4)),c("group_id","time_q","publicationyear","weight_eval")],c("time_q","publicationyear"),summarise, weight_q = mean(weight_eval, na.rm = T))
    # Annual: quarter 5
    tscount_a_w <- ddply(input_data[which(input_data$ics2 %in% ICS & input_data$origincode %in% country & input_data[,id] == 1 &  input_data$quarter == 5       ),c("group_id","time_q","publicationyear","weight_eval")],c("time_q","publicationyear"),summarise, weight_a = mean(weight_eval, na.rm = T))
    # Alternative: total annual
    tscount_alt_w <- ddply(input_data[which(input_data$ics2 %in% ICS & input_data$origincode %in% country & input_data[,id] == 1      ),c("group_id","time_q","publicationyear","weight_eval")],c("publicationyear"),summarise, weight_alt = mean(weight_eval, na.rm = T))
    # Alternative 2: total ICS
    tscount_alt2_w <- mean(input_data[which(input_data$ics2 %in% ICS & input_data$origincode %in% country & input_data[,id] == 1      ),c("weight_eval")], na.rm = T)
  }  
  ### Aggregation
  tscount_q <- ddply(input_data[which(input_data$ics2 %in% ICS & input_data$origincode %in% country & input_data[,id] == 1 &  input_data$quarter %in% c(1:4)),c("group_id","time_q","publicationyear")],c("time_q","publicationyear"),summarise, count_q = length(unique(group_id)))
  tscount_a <- ddply(input_data[which(input_data$ics2 %in% ICS & input_data$origincode %in% country & input_data[,id] == 1 &  input_data$quarter == 5       ),c("group_id","time_q","publicationyear")],c("time_q","publicationyear"),summarise, count_a = length(unique(group_id)))
  tscount_q <- merge(tscount_q[,c("time_q","count_q")],all_ts,by = "time_q",all=T)
  tscount  <- merge(tscount_q,tscount_a[,c("publicationyear","count_a")], by.x="year", by.y="publicationyear",all=T)
  tscount[is.na(tscount)] <- 0
  tscount$count <- tscount$count_q + (tscount$count_a/4)
  if (is.na(weight) == F) {
    tscount <- merge(tscount,tscount_q_w[,c("time_q","weight_q")],by = "time_q",all.x=T)
    tscount <- merge(tscount,tscount_a_w[,c("publicationyear","weight_a")],by.x="year", by.y="publicationyear",all.x=T)
    tscount <- merge(tscount,tscount_alt_w[,c("publicationyear","weight_alt")],by.x="year", by.y="publicationyear",all.x=T)
    if (weight == "pagecount") {
      # If page numbers are missing, fill up with annual or alternative measures
      tscount$weight_q[is.na(tscount$weight_q)] <- tscount$weight_a[is.na(tscount$weight_q)]
      tscount$weight_q[is.na(tscount$weight_q)] <- tscount$weight_alt[is.na(tscount$weight_q)]
      tscount$weight_a[is.na(tscount$weight_a)] <- tscount$weight_alt[is.na(tscount$weight_a)]
      tscount$weight_q[is.na(tscount$weight_q)] <- rep(tscount_alt2_w,nrow(tscount))[is.na(tscount$weight_q)]
      tscount$weight_a[is.na(tscount$weight_a)] <- rep(tscount_alt2_w,nrow(tscount))[is.na(tscount$weight_a)]
    } else {
      # Missing references imply zero references
      tscount$weight_q[is.na(tscount$weight_q)] <- 0
      tscount$weight_a[is.na(tscount$weight_a)] <- 0
    }
    # Weighted measures
    tscount$count <- tscount$count_q + tscount$count_q*tscount$weight_q + (tscount$count_a/4) + (tscount$count_a*tscount$weight_a)/4
  }
  # All reference counts after 2011-Q4 receive NA values as we do not have enough data for four years
  if (is.na(weight) == F) {
    if (weight == "count_ref") {
      tscount$count[which(tscount$year > 2011)] <- NA
    }
  }
  output_data <- tscount[,c("time_q","count")]
  names(output_data)[which(names(output_data)=="count")] <- name_series
  output_data
}
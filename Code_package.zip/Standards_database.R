Sys.time()
rm(list=ls())
dev.off()
library(openxlsx)
library(plyr)
library(readstata13)
library(here)
# Declare directory
setwd(here())  

###################################################################################################
# Read in all required datafiles
###################################################################################################

### A: Load custom-made functions__________________________________________________________________

source("R_files/SSO_names_harmonization.R")

### B: Load data files that are not in Searle Center Database______________________________________

# Data on ICS by SSO
sso_manual <- read.xlsx("Input_data/SSO_manual_designation.xlsx")
# Data from Perinorm and which includes all standards of all nationalities
load("Input_data/data_perinorm_eq.RData")
# Data on SSo nationality
sso_nationality  <- read.dta13("Input_data/SSOs.dta")

### C: Load data files from Searle Center Database_________________________________________________
# ICS codes
data_scdb_ics   <- read.dta13("../SSO/SCDB_ics codes.dta")
# Version history
data_scdb_vh    <- read.dta13("../SSO/SCDB_replacement.dta")
# References
data_scdb_ref   <- read.dta13("../SSO/SCDB_references.dta")
# Standards
data_scdb_base  <- read.dta13("../SSO/SCDB_standards.dta")
# SCDB-Perinorm
data_scdb_docid <- read.dta13("../SSO/SCDB_document_identifiers.dta")

###################################################################################################
# Step 1 : Cleaning
###################################################################################################

### A: Clean data_scdb_base________________________________________________________________________

# Unique values
data_scdb_base <- unique(subset(data_scdb_base,select = c(doc_idn,publicationyear,publicationmonth,publicationday,datasource,issuingbody,pagecount,origincode)))

#There are 62 ETSI standards with the same SCDB id, but sometimes different dates. Kick out 33 ETSI standards
data_scdb_base$date <- data_scdb_base$publicationyear*1000000+data_scdb_base$publicationmonth*1000+data_scdb_base$publicationday
data_scdb_base <- ddply(data_scdb_base,"doc_idn",mutate, mindate = min(date))
data_scdb_base <- data_scdb_base[-which(data_scdb_base$date != data_scdb_base$mindate),]

### B: Clean data_scdb_docid_______________________________________________________________________

# Unique values
data_scdb_docid <- unique(data_scdb_docid)

### C: Clean data_scdb_vh__________________________________________________________________________

# Unique values
data_scdb_vh <- unique(data_scdb_vh)

# Delete observations where replaced and replacing id are the same.
data_scdb_vh <- data_scdb_vh[-which(data_scdb_vh$doc_idn == data_scdb_vh$replaced_doc_idn),]

# There are some observations that are recorded in the wrong way.
# The replaced doc_idn and doc_idn should be switched. Take care of this via publication date
data_scdb_vh <- merge(data_scdb_vh,data_scdb_base[,c("doc_idn","publicationyear","publicationmonth","publicationday")],by = "doc_idn",all.x=T)
data_scdb_vh <- merge(data_scdb_vh,data_scdb_base[,c("doc_idn","publicationyear","publicationmonth","publicationday")],by.y = "doc_idn",by.x="replaced_doc_idn",all.x=T)
problematic_id <- which((data_scdb_vh$publicationyear.x == data_scdb_vh$publicationyear.y & data_scdb_vh$publicationmonth.x == data_scdb_vh$publicationmonth.y & data_scdb_vh$publicationday.x == data_scdb_vh$publicationday.y) |
                   (data_scdb_vh$publicationyear.x == data_scdb_vh$publicationyear.y & data_scdb_vh$publicationmonth.x < data_scdb_vh$publicationmonth.y) |
                   (data_scdb_vh$publicationyear.x < data_scdb_vh$publicationyear.y))
data_scdb_vh[problematic_id, c("doc_idn", "replaced_doc_idn")] <- data_scdb_vh[problematic_id, c("replaced_doc_idn", "doc_idn")]
data_scdb_vh <- subset(data_scdb_vh, select = - c(publicationyear.x,publicationyear.y,publicationmonth.x,publicationmonth.y,publicationday.x,publicationday.y))
rm(problematic_id)

### D: Clean data_scdb_ics_________________________________________________________________________

# Replace RWXXX with NA
data_scdb_ics$icscode <- gsub("RW[0-9][0-9][0-9]","",data_scdb_ics$icscode)

# Collpase ICS codes on 5digit-level
data_scdb_ics$ics5 <- substr(data_scdb_ics$icscode,1,6)
data_scdb_ics <- data_scdb_ics[which(as.numeric(nchar(data_scdb_ics$ics5)) > 0),]
data_scdb_ics$icscode <- NULL
data_scdb_ics <- unique(data_scdb_ics)

### E: Clean sso_manual____________________________________________________________________________

sso_manual <- reshape(sso_manual, 
                      varying = c("ICS", "X3", "X4", "X5"), 
                      v.names = "ics",
                      timevar = "temp", 
                      times = c("ICS", "X3", "X4", "X5"), 
                      direction = "long")
sso_manual <- sso_manual[,c("sso","ics")]
sso_manual <- sso_manual[which(is.na(sso_manual$ics)==F),]
sso_manual$ics2 <- substr(sso_manual$ics,1,2)
sso_manual$ics5 <- substr(sso_manual$ics,1,6)
sso_manual$ics5[which(nchar(sso_manual$ics5)==2)] <- NA

# Replace commas with dots
for (i in c(1:nrow(sso_manual))) {
  sso_manual$ics5[i] <- gsub("\\,","\\.",sso_manual$ics5[i])
}
rm(i)

###################################################################################################
# Step 2: Merge equivalents from Perinorm
###################################################################################################

data_scdb <- merge(data_scdb_base,unique(data_scdb_docid[,c("doc_idn","accode")]),by="doc_idn",all.x=T)
data_scdb <- merge(data_scdb,data_perinorm_eq[,c("code","groupids")],by.x = "accode", by.y = "code", all.x=T)
# Assign groupids to those standards that are not in data_perinorm_eq
data_scdb$group_id <- 3000000+c(1:nrow(data_scdb))
data_scdb$group_id <- as.integer(data_scdb$group_id)
data_scdb$group_id[which(is.na(data_scdb$groupids)==F)] <- data_scdb$groupids[which(is.na(data_scdb$groupids)==F)]
data_scdb$groupids <- NULL
                     
###################################################################################################
# Step 3: Identify first versions
###################################################################################################

data_scdb$first <- 1
data_scdb$first[which(data_scdb$doc_idn %in% unique(data_scdb_vh$doc_idn))] <- 0

###################################################################################################
# Step 4: Get number of references within 4 years of publication
###################################################################################################

# Merge publication date to both referencing and referenced standard
data_scdb_ref <- merge(data_scdb_ref,data_scdb_base[,c("doc_idn","publicationyear","publicationmonth")],by = "doc_idn", all.x = T)
data_scdb_ref <- merge(data_scdb_ref,data_scdb_base[,c("doc_idn","publicationyear","publicationmonth")],by.x = "doc_idn_cited", by.y = "doc_idn", all.x = T)
# Only keep those references that took place in the 4 years following the publication
data_scdb_ref <- data_scdb_ref[which((data_scdb_ref$publicationyear.x - data_scdb_ref$publicationyear.y <= 4) & data_scdb_ref$publicationyear.x - data_scdb_ref$publicationyear.y >= 0),]
# Count number of references
data_scdb_ref <- merge(data_scdb_ref,data_scdb[,c('doc_idn','group_id')],by.x = "doc_idn",by.y = "doc_idn")
data_scdb_ref <- ddply(unique(data_scdb_ref[,c("doc_idn_cited","group_id")]), "doc_idn_cited",summarise, count_ref = length(doc_idn_cited))
# Merge number of references to dataset
data_scdb <- merge(data_scdb,data_scdb_ref, by.x = "doc_idn", by.y="doc_idn_cited", all.x = T)
data_scdb$count_ref[is.na(data_scdb$count_ref)] <- 0

###################################################################################################
# Step 5: Merge ICS info to database and fill missing info where possible
###################################################################################################

# Two remedies:
# (1) if SSO in database, check which 5digit (and 2digit) code the SSO is usually receiving
# (2) manual designation of small SSOs at the 5digit level
# Remaining missing ICS info:
# Large SSOs like ETSI are categorized at the 2digit level, but receive the 5digit info ETSI

### A: Merge ICS data______________________________________________________________________________

data_scdb <- merge(data_scdb,data_scdb_ics,by="doc_idn", all.x = T)
data_scdb$ics2 <- substr(data_scdb$ics5,1,2)

### B: Preliminary step: Harmonize names of SSOs via acronyms______________________________________

data_scdb$sso <- sso_harm(data_scdb$issuingbody)
sso_manual$sso <- sso_harm(sso_manual$sso)

### C: Remedy 1____________________________________________________________________________________

#2digit
ics_sso_2digit <- as.data.frame(table(data_scdb[,c("sso","ics2")]))
ics_sso_2digit <- ics_sso_2digit[which(ics_sso_2digit$Freq > 0),]
ics_sso_2digit$sso <- as.character(ics_sso_2digit$sso)
ics_sso_2digit <- ddply(ics_sso_2digit,"sso", mutate, Freq_total = sum(Freq))
ics_sso_2digit <- ics_sso_2digit[which(ics_sso_2digit$Freq/ics_sso_2digit$Freq_total >=0.95),]
data_scdb$ics2[is.na(data_scdb$ics2)] <- ics_sso_2digit$ics2[match(data_scdb$sso,ics_sso_2digit$sso)][which(is.na(data_scdb$ics2))]
rm(ics_sso_2digit)

#5digit
ics_sso_5digit <- as.data.frame(table(data_scdb[,c("sso","ics5")]))
ics_sso_5digit <- ics_sso_5digit[which(ics_sso_5digit$Freq > 0),]
ics_sso_5digit$sso <- as.character(ics_sso_5digit$sso)
ics_sso_5digit <- ddply(ics_sso_5digit,"sso", mutate, Freq_total = sum(Freq))
ics_sso_5digit <- ics_sso_5digit[which(ics_sso_5digit$Freq/ics_sso_5digit$Freq_total >=0.95),]
data_scdb$ics5[is.na(data_scdb$ics5)] <- ics_sso_5digit$ics5[match(data_scdb$sso,ics_sso_5digit$sso)][which(is.na(data_scdb$ics5))]
rm(ics_sso_5digit)

### D: Remedy 2____________________________________________________________________________________

# Create 5digit category ETSI:
nrow(data_scdb[which(data_scdb$sso == "ETSI"),])
data_scdb$ics5[which(data_scdb$sso == "ETSI" & is.na(data_scdb$ics5))] <- "ETSI"

# data_scdb can be divided in 2 parts:
# data_scdb_1 are those for which there is no ICS: fill up with manual SSO info
# data_scdb_2 are those for which there is ICS: leave as it is
data_scdb_1 <- data_scdb[which(is.na(data_scdb$ics2) & is.na(data_scdb$ics5)),]
data_scdb_2 <- data_scdb[which(is.na(data_scdb$ics5)==F),]

# Fill in missing ICS info for data_scdb_1
data_scdb_1 <- merge(subset(data_scdb_1, select=-c(ics2,ics5)),subset(sso_manual, select = -c(ics)),by="sso", all.x = T)

# Combine
data_scdb <- unique(rbind(data_scdb_1,data_scdb_2))
rm(data_scdb_1,data_scdb_2)

###################################################################################################
# Step 6: SSO
###################################################################################################

data_scdb <- merge(data_scdb,sso_nationality, by = "issuingbody", all.x = T)
data_scdb$origincode[which(data_scdb$origincode=="")] <- data_scdb$countrycode[which(data_scdb$origincode=="")]
data_scdb$origincode[which(data_scdb$origincode=="EU")] <- "IX"

###################################################################################################
# Step 7: Quarterly indicator
###################################################################################################

data_scdb$quarter <- 5
data_scdb$quarter[which(data_scdb$publicationmonth >= 1)] <- 1
data_scdb$quarter[which(data_scdb$publicationmonth >= 4)] <- 2
data_scdb$quarter[which(data_scdb$publicationmonth >= 7)] <- 3
data_scdb$quarter[which(data_scdb$publicationmonth >= 10)] <- 4
data_scdb$time_q <- paste0(data_scdb$publicationyear,"-",data_scdb$quarter)

###################################################################################################
# Step 8: Some cleaning
###################################################################################################

# Kick out observations without year info
data_scdb <- data_scdb[which(is.na(data_scdb$publicationyear)==F),]

# Kick out WATTC
data_scdb <- data_scdb[-which(data_scdb$time_q == "1988-4" & data_scdb$issuingbody == "ITU Internationale Fernmeldeunion*ITU International Telecommunication Union" & data_scdb$ics5 == "33.020"),]
data_scdb <- data_scdb[-which(data_scdb$time_q == "1988-5" & data_scdb$issuingbody == "ITU Internationale Fernmeldeunion*ITU International Telecommunication Union" & data_scdb$ics5 == "33.020"),]
data_scdb <- data_scdb[-which(data_scdb$time_q == "1988-4" & data_scdb$issuingbody == "ITU Internationale Fernmeldeunion*ITU International Telecommunication Union" & data_scdb$ics5 == "33.040"),]
data_scdb <- data_scdb[-which(data_scdb$time_q == "1988-5" & data_scdb$issuingbody == "ITU Internationale Fernmeldeunion*ITU International Telecommunication Union" & data_scdb$ics5 == "33.040"),]

# Divide number of pages by 10
data_scdb$pagecount <- data_scdb$pagecount/10

###################################################################################################
# Step 9: Create an id to identify the earliest publication within a group of equivalent standards
###################################################################################################

# Create date
data_scdb$date <- data_scdb$publicationyear*1000000+data_scdb$quarter*1000

# Restrict to 1960-2014
data_scdb <- data_scdb[which(data_scdb$publicationyear >= 1960 & data_scdb$publicationyear <= 2014),]

# Base id for US and IX individually
data_scdb$group_country <- paste0(data_scdb$group_id,data_scdb$origincode)
data_scdb <- ddply(data_scdb,c("group_country"),mutate, mindate_ind = min(date))
data_scdb$base_id_ind <- 0
data_scdb$base_id_ind[which(data_scdb$date == data_scdb$mindate_ind)] <- 1
data_scdb <- data_scdb[which(data_scdb$base_id_ind == 1),]

# Base id for US and IX combined
data_scdb <- ddply(data_scdb,c("group_id"),mutate, mindate_com = min(date))
data_scdb$base_id_com <- 0
data_scdb$base_id_com[which(data_scdb$date == data_scdb$mindate_com)] <- 1

###################################################################################################
# Save dataset
###################################################################################################

save.image("Backup_data/Standards_database.RData")
